Maximus Decim Native USB ver.3.6

Only for Windows 98SE English !!!

*Native (without installation of additional drivers 
for each type) support USB flash drives, digital 
photo and videocameras and other similar devices.
*Universal Stack USB 2.0 (without installation 
of additional drivers for each chipsets) 
with uninstall.
1.Remove ALL drivers USB flash drives.
2.Remove ALL drivers USB 2.0 controllers.
3.Remove ALL USB 1.1 and 2.0 controllers and devices.
4.Remove ALL unknown devices.
5.Install NUSB 3.5 and reboot.
6.After detection new USB 1.1 and 2.0 controllers 
  (if it will occur) too it is necessary to be reboot.
Remember! You install it at own risk!

